 ######  ##         ##   ######## ##          ## ########   ######     ######## ######  ###### ##        ##
#               ##     ##     #           #  ####      ## #            ## #          #   #            # #             #          ####    ##
#                   ##          #           #  ##    ##  ## #            ## ######     #            # #    #### ###### #   ##  ##
 ######        ##          # ######  ##        ### #######    #          #   ########  #         #  #           #      ####
                                                                                                                            ####### ######

short skidded trojan :)
by Xuepiao
OS: Windows XP, Vista, 7, 8, 8.1, 10 and 11
OS support: Windows XP
creation date: December 24, 2023 (Merry Chirstmas)
this skidded trojan no joke, do you want to run it?